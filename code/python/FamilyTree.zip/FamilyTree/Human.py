class Human():
    """
    Representation of a Human

    variables:
        self.firstname
        self.lastname
        self.gender
        self.date_of_birth

    methods:
        __init__(self,first='unknown',last='unknown',gender='unknown',dob='2000-01-01')
        __str__(self)
        __repr__(self)
        first_name(self)    ... returns the first name as a string
        last_name(self)     ... returns the last name as a string
        full_name(self)
    """

    def __init__(self,first='unknown',last='unknown',gender='unknown',dob='2000-01-01'):
        self.firstname = first
        self.lastname  = last
        self.gender    = gender
        self.date_of_birth = dob

    def __str__(self):
        s =  "First name:    {}\n".format(self.firstname)
        s += "Last name:     {}\n".format(self.lastname)
        s += "Gender:        {}\n".format(self.gender)
        s += "date of birth: {}\n".format(self.date_of_birth)
        return s

    def __repr__(self):
        template="Human(first='{}',last='{}',gender='{}',dob='{}')"
        s = template.format(self.firstname,
                            self.lastname,
                            self.gender,
                            self.date_of_birth)
        return s

    def first_name(self):
        return self.firstname

    def last_name(self):
        return self.lastname

    def full_name(self):
        return "{} {}".format(self.firstname, self.lastname)


if __name__ == "__main__":

    human1 = Human()
    human2 = Human(first='John',last='Doe',gender='male',dob='1950-07-04')

    print(human1)
    print(human2)
