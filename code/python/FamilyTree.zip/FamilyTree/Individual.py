"""
=======================================
Exercise 2:  Designing a Family Tree
=======================================

We want to create a series of classes to represent entries in a family tree.
Each entry 'Individual' shall provide the following methods:

| method       |input|returns| notes                                      |
|:-------------|:----|:------|:-------------------------------------------|
| `first_name` | none| string|                                            |
| `last_name`  | none| string|                                            |
| `full_name`  | none| string| as `'first last'`                          |
| `gender`     | none| string| default to `'unknown'`                     |
| `DOB`        |     | string| date of birth as string `'YYYY-MM-DD'`     |
| `children`   |     | tuple | as a list of (pointers to) child objects   |
| `partner`    |     | tuple | as a list of (pointers to) partner objects,
                               most cases empty or one, but ...           |
| `add_child`  |child object|-| adds that child to the list of children   |
| `add_partner`|another
                individual
                object|      | add that partner to partner list           |
| `__str__`    |     | string| a nice representation of this `Individual` |


**Your Task**:

1. Given the `Human` class defined below, create the `Individual` class by deriving it from
   `Human` through **inheritance** and adding **only necessary** methods, thus, minimizing your effort.

2. add some simple test that creates a small family with parents and two children.
   Use `print(mom)` (or similar) to produce nice info.

"""


from Human import *

class Individual(Human):
    """
    Representation of an Individual

    variables:
        self.the_partner = []
        self.the_children = []

    variables (inherited):
        self.firstname
        self.lastname
        self.gender
        self.date_of_birth

    methods:
        __init__(self,first='unknown',last='unknown',gender='unknown',dob='2000-01-01')
        __str__(self)
        partner(self)
        children(self)
        add_partner(self, partner)
        add_child(self, child)
    """

    def __init__(self,first='unknown',last='unknown',gender='unknown',dob='2000-01-01'):
        super().__init__(first=first,last=last,gender=gender,dob=dob)
        self.the_partner  = []
        self.the_children = []

    def __str__(self):
        s = Human.__str__(self)
        s += "whatever else ...\n"
        return s

    def partner(self):
        pass

    def children(self):
        pass

    def add_partner(self, partner):
        pass

    def add_child(self, child):
        pass


if __name__ == "__main__":

    # creating Individuals

    dad  = Individual(first='Bob',last='Parr',gender='male',dob='1985-01-02')
    mom  = Individual(first='Helen',last='Parr',gender='female',dob='1980-03-04')
    girl = Individual(first='Violet',last='Parr',gender='female',dob='2002-05-06')
    boy  = Individual(first='Jack-Jack',last='Parr',gender='male',dob='2004-07-08')

    print(mom)
    print(dad)
