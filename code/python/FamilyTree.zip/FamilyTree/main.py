# This is the Family Tree Exercise

from Incredibles import *
from Disney import *


if __name__ == '__main__':

    IncrediblesExample1()
    #IncrediblesExample2()
    #IncrediblesExample3()
    DisneyExample()
