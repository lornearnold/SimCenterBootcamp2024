# a smarter way of creating connections

from AltIndividual import *

class SmartIndividual(AltIndividual):
    """
    Modify Individual to automatically generate bi-directional relationships
    """

    # YOUR CODE HERE ...
