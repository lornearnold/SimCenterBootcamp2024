# This is a sample Python script.

from MyDataType import *



if __name__ == '__main__':
    student1 = MyDataType()
    student2 = MyDataType(first='John',email='john.doe@hotmail.com')

    # sloppy printing statement
    print(student1)
    print(student2)
