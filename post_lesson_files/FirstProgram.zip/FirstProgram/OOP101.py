s = "Peter\nPaul\nMary"

a = s.split("\n")
b = "-".join(['A','B','C'])

print(a)
print(b)
print(b.upper())
print(b.lower())